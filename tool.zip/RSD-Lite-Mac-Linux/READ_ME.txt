How to use rsd-flash.sh
1. open a terminal and cd to RSD-Lite-Mac-Linux folder
2. extract and copy all of the motorola firmware files to RSD-Lite-Mac-Linux folder
3. command ./rsd-flash.sh [name of your XML file]
4. enter to start
5. watch for errors if none at the end of script press enter again to reboot device

Note Motorola device must be in Bootloader / AP Fastboot mode to use this tool
1. power off phone
2. hold volume down and power to boot AP fastboot mode
